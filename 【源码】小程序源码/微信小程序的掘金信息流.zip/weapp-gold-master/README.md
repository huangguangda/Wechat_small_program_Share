WeApp - 掘金
========

* 模拟掘金首页信息流
* 路由跳转文章页

## 预览

![](https://github.com/hilongjw/weapp-gold/blob/master/preview.gif)

## 使用

克隆本项目 -> 在微信开发工具中添加项目 -> 选择项目目录

## 相关资源

[weapp-ide-crack](https://github.com/gavinkwoe/weapp-ide-crack/blob/master/README.md) - 微信小应用资源破解



