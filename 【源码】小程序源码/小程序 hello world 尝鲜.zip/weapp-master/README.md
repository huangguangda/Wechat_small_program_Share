

### 简单的微信小程序hello world（轮播图+菜单）,对于做过react/vue/ng表示毫无压力，上手无门槛。（对前端来说 要多维护一个平台了。。。多加班的节奏）

- 文档 [http://notedown.cn/weixin/](http://notedown.cn/weixin/)
- 官方文档 [https://mp.weixin.qq.com/debug/wxadoc/dev/index.html](https://mp.weixin.qq.com/debug/wxadoc/dev/index.html)
- IDE 以及破解 [https://github.com/gavinkwoe/weapp-ide-crack](https://github.com/gavinkwoe/weapp-ide-crack)

![Alt text](./1.png)

*数据为模拟的假数据