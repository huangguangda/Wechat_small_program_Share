# wxappblog
微信小程序-小波说雨燕blog
被微信小程序刷屏, 利弊得失先不去想, 玩一玩才是真的.

动手把这个博客实现了一下,虽然很简陋, 不过应该足以理解微信小程序的运作了.

效果如下:

<img class="alignnone size-full wp-image-224" src="http://www.xiaoboswift.com/wp-content/uploads/2016/09/微信小程序.gif" alt="%e5%be%ae%e4%bf%a1%e5%b0%8f%e7%a8%8b%e5%ba%8f" width="251" height="490" />


源码: https://github.com/yagamis/wxappblog

微信小程序开发IDE下载

注意:开发前需要申请微信公共号并开通开发者权限.

入门视频: http://edu.51cto.com/course/course_id-7242.html



