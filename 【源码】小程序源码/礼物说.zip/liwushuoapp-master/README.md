# liwushuoapp
微信小程序开发的app---礼物说APP

再根目录 80端口 起服务 获取mock数据
