Page({
  data: {
    imgUrls: [
      'http://img01.liwushuo.com/image/160809/0s2zx2x1t.jpg-w720',
      'http://img01.liwushuo.com/image/161017/bbc4rxmue.jpg-w720',
      'http://img03.liwushuo.com/image/161017/32qld5uuv.jpg-w720',
      'http://img03.liwushuo.com/image/141215/3bc11oh4n.jpg-w720',
      'http://img03.liwushuo.com/image/161013/2003ddy5r.jpg-w720',
      'http://img03.liwushuo.com/image/151130/v2vuunmlo.jpg-w720',
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 1000
  },
})
