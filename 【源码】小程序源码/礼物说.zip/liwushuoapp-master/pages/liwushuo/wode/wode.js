Page({
  data: {
    current: 0
  },
  onLoad: function () {
    // console.log('loaded.');
  }
});
