
// API_KEY
const API_KEY="9dc7ab2f8993b0b215ad8c550e1f4ebe";
//空气质量检测的URL参考 
const AIR_QUALITY_URL="http://apis.baidu.com/apistore/aqiservice/aqi";



module.exports = {
    AIR_QUALITY_URL: AIR_QUALITY_URL,
    API_KEY:API_KEY
}
