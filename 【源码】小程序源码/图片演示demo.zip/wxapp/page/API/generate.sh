mkdir $1
touch $1/$1.js
touch $1/$1.wxss
touch $1/$1.wxml
touch $1/$1.json
