# 微信小程序开发项目——笑话大全

###此项目是学习完微信小程序后实现的一个demo，采用[聚合数据](https://www.juhe.cn/)的免费api获取最新的文本笑话和趣图（图片和gif图）




![](https://github.com/zhijieeeeee/wechat-app-joke/blob/master/screenshot/joke.png)
![](https://github.com/zhijieeeeee/wechat-app-joke/blob/master/screenshot/picture.png)