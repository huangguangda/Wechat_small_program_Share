var data = {
    "diaries": [
        {
            "image": "http://m.chanyouji.cn/index-cover/64695-2679221.jpg?imageView2/1/w/620/h/330/format/jpg",
            "avatar": "http://a.chanyouji.cn/34350/1468906824.jpg",
            "title": "梦想实现的地方-马达加斯加第二季",
            "meta": "2013年8月10日 / 6天 / 476图",
            "nickname": "SmallClock",
        },
        {
            "image": "http://m.chanyouji.cn/articles/625/ca9e50f74e273041e3a399bf5528f7b5.jpg?imageView2/1/w/620/h/330/format/jpg",
            "avatar": "http://tva3.sinaimg.cn/crop.0.0.540.540.50/6cbb1ee0jw8ej0zou5e71j20f00f0q3b.jpg",
            "title": "濑户内海北半圈-历史、艺术与兔子",
            "meta": "2016年9月1日 / 6天 / 476图",
            "nickname": "TinyClock",
        },
        {
            "image": "http://m.chanyouji.cn/articles/625/ca9e50f74e273041e3a399bf5528f7b5.jpg?imageView2/1/w/620/h/330/format/jpg",
            "avatar": "http://tva3.sinaimg.cn/crop.0.0.540.540.50/6cbb1ee0jw8ej0zou5e71j20f00f0q3b.jpg",
            "title": "濑户内海北半圈-历史、艺术与兔子",
            "meta": "2016年9月1日 / 6天 / 476图",
            "nickname": "狗小熊",
        },
        {
            "image": "http://m.chanyouji.cn/articles/625/ca9e50f74e273041e3a399bf5528f7b5.jpg?imageView2/1/w/620/h/330/format/jpg",
            "avatar": "http://tva3.sinaimg.cn/crop.0.0.540.540.50/6cbb1ee0jw8ej0zou5e71j20f00f0q3b.jpg",
            "title": "濑户内海北半圈-历史、艺术与兔子",
            "meta": "2016年9月1日 / 6天 / 476图",
            "nickname": "Bear",
        },
        {
            "image": "http://m.chanyouji.cn/articles/625/ca9e50f74e273041e3a399bf5528f7b5.jpg?imageView2/1/w/620/h/330/format/jpg",
            "avatar": "http://tva3.sinaimg.cn/crop.0.0.540.540.50/6cbb1ee0jw8ej0zou5e71j20f00f0q3b.jpg",
            "title": "濑户内海北半圈-历史、艺术与兔子",
            "meta": "2016年9月1日 / 6天 / 476图",
            "nickname": "山田さん",
        },
        {
            "image": "http://m.chanyouji.cn/articles/625/ca9e50f74e273041e3a399bf5528f7b5.jpg?imageView2/1/w/620/h/330/format/jpg",
            "avatar": "http://tva3.sinaimg.cn/crop.0.0.540.540.50/6cbb1ee0jw8ej0zou5e71j20f00f0q3b.jpg",
            "title": "濑户内海北半圈-历史、艺术与兔子",
            "meta": "2016年9月1日 / 6天 / 476图",
            "nickname": "小熊的日常",
        }
    ],

    dairys: [
        {
            "cover": "http://m.chanyouji.cn/articles/625/ca9e50f74e273041e3a399bf5528f7b5.jpg?imageView2/1/w/620/h/330/format/jpg",
        }
    ]
}

module.exports = {
    "data": data
}
