# wechat-weapp-buycar
微信小程序-大好商城demo

##1.首页
![](./demo.png)
##2.分类
![](./demo4.png)
##3.个人中心
![](./demo3.png)


##本人是做android开发，此项目是最近没事做着玩的，前端大神勿喷，按照API文档实现的布局，里面具体的逻辑和功能有待完善，敬请期待！欢迎star，fork


###[微信开发文档](https://mp.weixin.qq.com/debug/wxadoc/dev/api/?t=1475052047016)
###[微信开发工具下载](https://mp.weixin.qq.com/debug/wxadoc/dev/devtools/download.html?t=1475052055364)
##有问题可以加我微信咨询
![](./wx.jpeg)