Page({
    data: {
        // text:"这是一个页面"
        des: '关注是一种欣赏的态度',
        userInfo: {
            nickName: '杨哲丶',
            avatarUrl: '../img/weixin_icon.jpg'
        }
    },
    onLoad: function (options) {
        // 页面初始化 options为页面跳转所带来的参数

    }
})