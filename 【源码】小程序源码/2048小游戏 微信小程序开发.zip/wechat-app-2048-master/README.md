# wechat-app-2048  微信小程序 2048游戏

* 本人是后端工程师，1天也能学习并做出2048小游戏的Demo，充分说明了微信小应用的门槛很低，希望能共同交流，我会不断完善这个小游戏
* 游戏截图

![weixin](./images/2048.png)

* 所在公司  [番薯小报](http://fanshuapp.com)
* 个人微信：chefendou

![weixin](./images/erweima.jpg)
