# 微信小程序示例

![preview](screenshot.gif)

## LICENSE

And of course:
[MIT](http://rem.mit-license.org)
