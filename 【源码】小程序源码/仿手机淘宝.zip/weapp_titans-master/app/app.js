/*
 *Created by songroger on Oct.10.2016.
 app.js是小程序的脚本代码.我们可以在这个文件中监听并处理小程序的生命周期函数、声明全局变量.在其他文件使用时，通过全局函数 getApp() 获取全局的应用实例
 */
App({
    globalPoem: {
        text: "",
        title:"",
        author:""
    }
});